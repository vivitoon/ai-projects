"""
Mock Airbyte data pipeline — conceptual integration.
In production, Airbyte would sync check-in data to a data warehouse for analytics,
and pull in data from EHR/pharmacy sources.
"""

from fastapi import APIRouter, Depends

from app.auth import verify_token
from app.database import get_db

router = APIRouter(prefix="/api/pipeline", tags=["pipeline"])


@router.get("/export")
async def export_data(_user: dict = Depends(verify_token)):
    """Export all check-in data as JSON — simulates Airbyte data sync."""
    db = get_db()
    return {
        "source": "carecompanion",
        "destination": "data_warehouse",
        "pipeline": "airbyte",
        "data": {
            "seniors": db.scan("seniors"),
            "checkins": db.scan("checkins"),
            "alerts": db.scan("alerts"),
        },
        "note": "In production, Airbyte syncs this data to BigQuery/Snowflake for analytics dashboards.",
    }
