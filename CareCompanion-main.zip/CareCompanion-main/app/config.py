from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Bland AI
    bland_ai_api_key: str = ""

    # Auth0
    auth0_domain: str = ""
    auth0_api_audience: str = ""
    auth0_client_id: str = ""

    # Aerospike
    aerospike_host: str = "localhost"
    aerospike_port: int = 3000
    use_aerospike: bool = False

    # Google Places API (optional — for dynamic service lookup)
    google_places_api_key: str = ""

    # App
    base_url: str = "http://localhost:8000"
    skip_auth: bool = True

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()
