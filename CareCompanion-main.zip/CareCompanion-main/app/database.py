"""
Database layer with Aerospike + in-memory fallback.
Uses Aerospike when USE_AEROSPIKE=true, otherwise a simple dict store.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from typing import Any

from app.config import settings

logger = logging.getLogger(__name__)

NAMESPACE = "test"  # Aerospike Community Edition default namespace


class InMemoryStore:
    """Dict-based store that mirrors the Aerospike interface."""

    def __init__(self) -> None:
        self._data: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)

    def put(self, set_name: str, key: str, record: dict[str, Any]) -> None:
        self._data[set_name][key] = record

    def get(self, set_name: str, key: str) -> dict[str, Any] | None:
        return self._data[set_name].get(key)

    def scan(self, set_name: str) -> list[dict[str, Any]]:
        return list(self._data[set_name].values())

    def delete(self, set_name: str, key: str) -> bool:
        return self._data[set_name].pop(key, None) is not None

    def scan_prefix(self, set_name: str, prefix: str) -> list[dict[str, Any]]:
        return [
            v for k, v in self._data[set_name].items() if k.startswith(prefix)
        ]


class AerospikeStore:
    """Aerospike-backed store with the same interface as InMemoryStore."""

    def __init__(self, host: str, port: int) -> None:
        import aerospike
        config = {"hosts": [(host, port)]}
        self._client = aerospike.client(config).connect()
        logger.info("Connected to Aerospike at %s:%d", host, port)

    def put(self, set_name: str, key: str, record: dict[str, Any]) -> None:
        """Store entire record as a single JSON blob in one bin."""
        aero_key = (NAMESPACE, set_name, key)
        self._client.put(aero_key, {"data": json.dumps(record)})

    def _parse(self, bins: dict) -> dict[str, Any]:
        return json.loads(bins.get("data", "{}"))

    def get(self, set_name: str, key: str) -> dict[str, Any] | None:
        import aerospike
        aero_key = (NAMESPACE, set_name, key)
        try:
            _, _, bins = self._client.get(aero_key)
            return self._parse(bins)
        except aerospike.exception.RecordNotFound:
            return None

    def scan(self, set_name: str) -> list[dict[str, Any]]:
        results = []
        scan = self._client.scan(NAMESPACE, set_name)
        scan.foreach(lambda record: results.append(self._parse(record[2])))
        return results

    def delete(self, set_name: str, key: str) -> bool:
        import aerospike
        aero_key = (NAMESPACE, set_name, key)
        try:
            self._client.remove(aero_key)
            return True
        except aerospike.exception.RecordNotFound:
            return False

    def scan_prefix(self, set_name: str, prefix: str) -> list[dict[str, Any]]:
        results = []
        scan = self._client.scan(NAMESPACE, set_name)

        def callback(record):
            key_tuple, _, bins = record
            pk = key_tuple[2] if key_tuple[2] else ""
            if isinstance(pk, str) and pk.startswith(prefix):
                results.append(self._parse(bins))

        scan.foreach(callback)
        return results


# Global database instance
db: InMemoryStore | AerospikeStore | None = None


def init_db() -> InMemoryStore | AerospikeStore:
    """Initialize the database — call once at startup."""
    global db
    if settings.use_aerospike:
        try:
            db = AerospikeStore(settings.aerospike_host, settings.aerospike_port)
            logger.info("Using Aerospike database")
        except Exception as e:
            logger.warning("Aerospike connection failed (%s) — falling back to in-memory", e)
            db = InMemoryStore()
    else:
        db = InMemoryStore()
        logger.info("Using in-memory database")
    return db


def get_db() -> InMemoryStore | AerospikeStore:
    global db
    if db is None:
        db = init_db()
    return db
