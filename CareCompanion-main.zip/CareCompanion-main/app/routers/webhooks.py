"""Bland AI webhook receiver — processes completed calls (outbound and inbound)."""

from __future__ import annotations

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Request

from app.database import get_db
from app.models.checkin import CheckIn
from app.services.bland_ai import call_id_to_phone
from app.services.call_analyzer import analyze_transcript
from app.services.alert_engine import evaluate_checkin
from app.services.service_directory import find_services

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])


def _process_call(call_id: str, transcript: str, status: str, senior_phone: str) -> dict:
    """Shared logic for processing completed calls."""
    db = get_db()
    senior_record = db.get("seniors", senior_phone)
    senior_name = senior_record.get("name", "") if senior_record else ""

    now = datetime.now(timezone.utc).isoformat()

    if status in ("no-answer", "voicemail", "failed"):
        checkin = CheckIn(
            senior_phone=senior_phone,
            call_id=call_id,
            timestamp=now,
            mood="unknown",
            wellness_score=0,
            concerns=["no_answer"],
            summary=f"Call {status} — senior did not answer",
        )
    else:
        analysis = analyze_transcript(transcript)
        checkin = CheckIn(
            senior_phone=senior_phone,
            call_id=call_id,
            timestamp=now,
            transcript=transcript,
            mood=analysis["mood"],
            wellness_score=analysis["wellness_score"],
            medication_taken=analysis["medication_taken"],
            concerns=analysis["concerns"],
            service_requests=analysis["service_requests"],
            summary=analysis["summary"],
        )

    # Store check-in
    checkin_key = f"{senior_phone}:{now}"
    db.put("checkins", checkin_key, checkin.model_dump())
    logger.info("Stored check-in %s for %s", checkin_key, senior_name or senior_phone)

    # Evaluate alerts
    alerts = evaluate_checkin(checkin, senior_name)

    # For service requests, attach recommended services to each alert
    for svc in checkin.service_requests:
        services = find_services(svc["type"])
        if services:
            svc_key = f"{senior_phone}:{now}:services_{svc['type']}"
            db.put("service_recommendations", svc_key, {
                "senior_phone": senior_phone,
                "senior_name": senior_name,
                "request_type": svc["type"],
                "label": svc["label"],
                "timestamp": now,
                "recommended_services": services,
            })

    return {
        "status": "processed",
        "checkin_key": checkin_key,
        "alerts_raised": len(alerts),
        "service_requests": len(checkin.service_requests),
    }


@router.post("/bland/call-complete")
async def bland_call_complete(request: Request):
    """Webhook called by Bland AI when an outbound call completes."""
    body = await request.json()
    logger.info("Received Bland AI outbound webhook: %s", body)

    call_id = body.get("call_id", "")
    transcript = body.get("concatenated_transcript", "") or body.get("transcript", "")
    status = body.get("status", "completed")

    senior_phone = call_id_to_phone.pop(call_id, None)
    if not senior_phone:
        logger.warning("Received webhook for unknown call_id: %s", call_id)
        return {"status": "ignored", "reason": "unknown call_id"}

    return _process_call(call_id, transcript, status, senior_phone)


@router.post("/bland/inbound-complete")
async def bland_inbound_complete(request: Request):
    """Webhook called by Bland AI when an inbound call completes."""
    body = await request.json()
    logger.info("Received Bland AI inbound webhook: %s", body)

    call_id = body.get("call_id", "")
    transcript = body.get("concatenated_transcript", "") or body.get("transcript", "")
    status = body.get("status", "completed")
    from_number = body.get("from", "") or body.get("caller_phone", "")

    if not from_number:
        logger.warning("Inbound call with no caller number: %s", call_id)
        return {"status": "ignored", "reason": "no caller number"}

    # Try to match caller to a known senior
    db = get_db()
    senior_record = db.get("seniors", from_number)
    if not senior_record:
        # Try scanning all seniors to match
        seniors = db.scan("seniors")
        for s in seniors:
            if s.get("phone", "").replace("+", "") == from_number.replace("+", ""):
                from_number = s["phone"]
                senior_record = s
                break

    if not senior_record:
        # Unknown caller — still process but log it
        logger.info("Inbound call from unknown number: %s", from_number)

    return _process_call(call_id, transcript, status, from_number)


@router.post("/bland/mock-complete")
async def mock_call_complete(request: Request):
    """Mock endpoint to simulate a completed call for demo/testing."""
    body = await request.json()

    call_id = body.get("call_id", "")
    transcript = body.get("transcript", "I'm feeling good today. Yes I took my medications. Everything is fine.")
    status = body.get("status", "completed")

    fake_payload = {
        "call_id": call_id,
        "concatenated_transcript": transcript,
        "status": status,
    }

    class FakeRequest:
        async def json(self):
            return fake_payload

    return await bland_call_complete(FakeRequest())
