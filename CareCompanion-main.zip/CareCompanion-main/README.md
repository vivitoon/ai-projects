# CareCompanion

Voice-first AI senior care companion. Daily automated phone check-ins keep seniors safe and families informed — plus on-demand service requests for shower help, food, medicine, mail, transportation, and emergencies.

## How It Works

### Outbound (Daily Check-ins)
1. **Bland AI** calls your loved one daily for a friendly check-in
2. Covers: how they're feeling, medication compliance, and any concerns
3. Detects service needs: "I need help showering", "I'm hungry", "I need my medicine"
4. Transcripts analyzed for mood, wellness score, and red flags
5. **Alerts** fire automatically — family sees them on the dashboard with recommended local services

### Inbound (Senior Calls Anytime)
1. Senior dials the CareCompanion phone number (Bland AI inbound)
2. AI assistant helps with: food ordering, medicine refills, shower help, mail, rides, emergencies
3. Automatically notifies family and recommends local services in San Francisco

## Features

- **Voice Check-ins** — Bland AI conducts natural phone conversations with seniors
- **Service Request Detection** — Identifies needs for shower help, food, medicine, mail, transportation, companionship
- **Local Service Directory** — Pre-loaded SF services (Meals on Wheels, pharmacies, paratransit, etc.)
- **Smart Alerts** — Critical (emergency/falls), High (low mood), Medium (missed meds, service requests)
- **Family Dashboard** — Real-time senior status, wellness trends, alerts, service requests
- **Auto-Scheduling** — Daily check-in calls via APScheduler

## Tech Stack

| Tool | Role |
|------|------|
| **Bland AI** | Voice agent — outbound check-in calls + inbound help line |
| **Auth0** | Secures family dashboard login |
| **Aerospike** | Real-time data storage (in-memory fallback for dev) |
| **Airbyte** | Data pipeline for analytics export |
| **FastAPI** | Python backend API |

## Quick Start

```bash
# Install dependencies
uv sync

# Configure API keys
# Edit .env with your BLAND_AI_API_KEY

# Start the server
uv run python main.py

# Seed demo data (in another terminal)
uv run python scripts/seed_data.py

# Open dashboard
open http://localhost:8000
```

## For Live Calls

```bash
# 1. Get Bland AI API key from bland.ai
# 2. Set BLAND_AI_API_KEY in .env
# 3. Start ngrok tunnel
ngrok http 8000
# 4. Set BASE_URL in .env to your ngrok URL
# 5. Restart server and trigger a call from dashboard
```

## Service Categories

| Service | Detection Keywords | SF Providers |
|---------|-------------------|--------------|
| Shower/Bath Help | shower, bath, washing | Home Instead, Visiting Angels |
| Medicine/Rx | prescription, refill, pharmacy | Walgreens Delivery, CVS |
| Food/Meals | hungry, food, groceries, cook | Meals on Wheels SF, Project Open Hand |
| Mail/Packages | mail, mailbox, package, post | USPS Carrier Pickup, SF Senior Center |
| Transportation | ride, appointment, doctor | SF Paratransit, GoGoGrandparent |
| Medical Emergency | chest pain, fall, 911 | 911, UCSF Medical, SF General |
| Companionship | lonely, alone, visit | Institute on Aging Friendship Line |

## API Endpoints

### Seniors
- `POST /api/seniors` — Add a senior
- `GET /api/seniors` — List all seniors
- `GET /api/seniors/{phone}` — Get senior details
- `PUT /api/seniors/{phone}` — Update senior
- `DELETE /api/seniors/{phone}` — Remove senior

### Check-ins
- `POST /api/checkins/trigger/{phone}` — Trigger a check-in call
- `GET /api/checkins/{phone}` — Check-in history for a senior
- `GET /api/checkins/latest/all` — Latest check-in per senior

### Alerts
- `GET /api/alerts` — Active alerts
- `PUT /api/alerts/{id}/acknowledge` — Acknowledge alert

### Services
- `GET /api/services` — Full service directory
- `GET /api/services/{type}` — Services by category
- `GET /api/services/recommendations/recent` — Recent service recommendations

### Webhooks (Bland AI)
- `POST /api/webhooks/bland/call-complete` — Outbound call webhook
- `POST /api/webhooks/bland/inbound-complete` — Inbound call webhook

### Pipeline
- `GET /api/pipeline/export` — Export all data (Airbyte mock)

## Architecture

See [docs/architecture.html](docs/architecture.html) for interactive diagrams.
